library(shiny)
library(ggplot2)
library(dplyr)
library(plotly)
library(FactoMineR)
library(factoextra)
library(shinythemes)

whr_2023 <- read_csv("/home/jovyan/100-sp24/Final_Proj/data/whr-2023.csv", show_col_types = FALSE)

ui <- fluidPage(
  titlePanel("World Happiness Report 2023 Analysis"),
  theme = shinythemes::shinytheme("darkly"),  # Set the "darkly" theme
  sidebarLayout(
    sidebarPanel(
      selectInput("xvar", "X-axis variable:",
                  choices = names(whr_2023)[3:11]),
      selectInput("yvar", "Y-axis variable:",
                  choices = names(whr_2023)[3:11], selected = names(whr_2023)[4]),
      selectInput("colorvar", "Color by:",
                  choices = c("None", names(whr_2023)[3:11])),
      selectInput("sizevar", "Size by:",
                  choices = c("None", names(whr_2023)[3:11])),
      checkboxInput("addPCA", "Add PCA Analysis", value = FALSE)
    ),
    mainPanel(
      plotlyOutput("scatterPlot"),
      conditionalPanel(
        condition = "input.addPCA == true",
        plotlyOutput("pcaPlot")
      )
    )
  )
)

server <- function(input, output) {
  
  quote_name <- function(name) {
    if (grepl(" ", name)) {
      return(paste0("`", name, "`"))
    }
    return(name)
  }
  
  output$scatterPlot <- renderPlotly({
    xvar <- quote_name(input$xvar)
    yvar <- quote_name(input$yvar)
    colorvar <- if (input$colorvar != "None") quote_name(input$colorvar) else NULL
    sizevar <- if (input$sizevar != "None") quote_name(input$sizevar) else NULL
    
    # compute correlation
    correlation = cor(whr_2023[[input$xvar]], whr_2023[[input$yvar]], use="complete.obs")
    correlation_text = paste("ρ =", round(correlation, 2))
    
    # adjust x and y position for plotting
    x_position <- min(whr_2023[[input$xvar]], na.rm = TRUE) + 0.05 * (max(whr_2023[[input$xvar]], na.rm = TRUE) - min(whr_2023[[input$xvar]], na.rm = TRUE))
    y_position <- max(whr_2023[[input$yvar]], na.rm = TRUE) - 0.05 * (max(whr_2023[[input$yvar]], na.rm = TRUE) - min(whr_2023[[input$yvar]], na.rm = TRUE))
    
    # scatterplot
    p <- ggplot(whr_2023, aes_string(x = xvar, y = yvar)) +
      geom_point(aes_string(
        color = colorvar,
        size = sizevar
      )) +
      labs(title = "Scatter Plot", x = input$xvar, y = input$yvar) +
      annotate("text", x = x_position, 
               y = y_position, 
               label = correlation_text, hjust = 0, vjust = 1, size = 5, color = "black") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))
    
    ggplotly(p)
  })
  
  # pca plot
  output$pcaPlot <- renderPlotly({
    pca_data <- whr_2023 %>% select(3:11) %>% na.omit()
    pca_result <- PCA(pca_data, graph = FALSE)
    p <- fviz_pca_biplot(pca_result,
                         repel = TRUE,
                         col.var = "blue",
                         col.ind = "red") +
      labs(title = "PCA Biplot")
    ggplotly(p)
  })
}

shinyApp(ui = ui, server = server)
